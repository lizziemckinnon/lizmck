//Lizzie McKinnon; CIS 340 T\TH 1:30PM; A7emckinno
import java.util.Scanner;
import java.util.ArrayList;

public class LibrarySystem {
private ArrayList<Book>books;
	
	public LibrarySystem()
	{
		//ArrayList of books
		books = new ArrayList<>();
	}
	public static void main(String[] args) {
        // TODO Auto-generated method stub
		
    LibrarySystem librarySystem = new LibrarySystem();
    //calls each method 
    librarySystem.displayHeader();
    System.out.println();
    librarySystem.loadLibrarySystem();
    System.out.println();
    librarySystem.displayBookList();
  
	}
	
	//displayHeader method
	public void displayHeader()
	{
		//writes title of application
		System.out.println("\t\t\tNew Library System\n");
	}
	
	//addBook method
	public void addBook()
	{
		//asks user for information on book and adds to ArrayList
		Scanner scnr = new Scanner(System.in);
		System.out.print("\nEnter Book title: ");
		String title = scnr.nextLine();
		System.out.print("Enter Book Year: ");
		int year = scnr.nextInt();
		Book book = new Book( title , year);
		books.add(book);
		System.out.printf("Title '%s' added to the library.", title);
	}
	
	//displayBookList method
	public void displayBookList()
	{
	    displayHeader();
	    //formats book titles and year
	    System.out.printf("%-20s%62s\n", "Title" , "Year");
	    for (Book b:books)
	    {
	        System.out.println(b);
	    }
	}
	
	//loadLibrarySystem method
	public void loadLibrarySystem()
	{
		//asks users how many books are needed
	    Scanner scnr = new Scanner(System.in);
	    System.out.print("How many books do you want to add to the library? ");
	    int n = scnr.nextInt();
	    
	    //for loop to display addBook method for book title and year
	    for (int i = 0; i<n; i++)
	    {
	        addBook();

	    }
	    System.out.println("\nAdding books complete. Press enter to continue.");

      }
}
