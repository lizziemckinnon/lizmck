public class Book {
	
	  private String title = "";
	  private int year = 0 ;

	  public Book(String bookTitle, int bookYear)
	   {
	        this.title = bookTitle;
	        setYear(bookYear);
	   }
	  //setter for book year
	  private void setYear(int year)
	   {
	        if (year >= 1100 && year <= 2019)
	        {
	            this.year = year;
	        }
	        else
	            this.year = 1900;
	   }
	  //setter for book title
	   public void setTitle(String title)
	   {
	        this.title = title;
	   }
	   //getter for book year
	   private int getYear()
	   {
	        return year;
	   }
	   private String getTitle()
	   {
		   return title;
	   }
	   //format book title and year 
	   public String toString() 
	   {
	    return String.format("%-41s%41s", title, year);
	   }
	   
}
